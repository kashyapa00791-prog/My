# AK License Manager

A PHP 7.4+ / MySQLi license-management starter for authorized applications. It is not a guarantee of production security; review the deployment checklist before use.

## Files
- `config.php`: database, secret, sessions, helper functions
- `db.sql`: schema and tier seed data
- `api.php`: POST API entry point
- `admin/`: dashboard, users, keys, logs, sessions, settings
- `admin/setup_admin.php`: one-time first-admin setup; delete after use
- `.htaccess`: Apache access restrictions and HTTPS redirect

## Requirements
- PHP 7.4+ with MySQLi, JSON, password hashing, and sessions
- MySQL 5.7+ or compatible MariaDB
- HTTPS certificate and Apache `.htaccess` support for the included rules

## Shared hosting setup
1. Create a MySQL database and database user in your hosting control panel. Grant the user privileges on that database. Host/database names on shared hosting often include an account prefix.
2. Open phpMyAdmin and select the created database. Import `db.sql`. If your host does not permit `CREATE DATABASE`, remove the first two lines (`CREATE DATABASE...` and `USE license_manager;`) and import into the selected database.
3. Edit `config.php` with the exact host, database, username and password supplied by the host.
4. Generate a random secret on a trusted machine: `php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"`. Put the output in `CLIENT_SECRET`. Do not reuse the example value.
5. Upload the files using the hosting File Manager or SFTP/FTPS. Place them in the intended web root. Avoid plain FTP where possible.
6. Set `config.php` to the strictest permissions supported (often `600` or `640`); the web server still needs read access. File permissions do not replace access restrictions.
7. Enable SSL in the hosting panel. Many shared hosts issue and renew Let's Encrypt certificates automatically. Verify HTTPS before enabling `COOKIE_SECURE=true`.
8. Visit `/admin/setup_admin.php`, create a strong admin password (12+ characters), then **delete `admin/setup_admin.php` immediately**.
9. Visit `/admin/login.php` and sign in with the admin account you created.
10. Confirm `api.php` is reachable over HTTPS and check PHP error logs if a generic error appears.

## InfinityFree / Hostinger / AwardSpace
The exact control-panel labels differ. Create a MySQL database and user under the database section, import through phpMyAdmin, then copy the assigned database hostname and prefixed database name into `config.php`. Free hosts may restrict outbound requests, PHP features, `.htaccess` directives, or API response time. Test the host before depending on it. 000webhost availability and product offerings may change; use a currently supported provider if signup/deployment is unavailable.

## API signatures
`login`: HMAC-SHA256 of `timestamp . device_hash`
`verify`: HMAC-SHA256 of `timestamp . device_hash . license_key`
`heartbeat` / `logout`: HMAC-SHA256 of `timestamp . device_hash . token`
`user_info`: HMAC-SHA256 of `timestamp . token`

All signatures are hex encoded. Timestamp is Unix UTC seconds and must be within ±300 seconds. Send `signature` as lowercase or uppercase hex; the server normalizes it.

Important: a shared HMAC secret embedded in a distributed client can be extracted. A timestamp does not stop an attacker who can obtain the secret from generating signatures. For stronger production designs, use a public-key client signature scheme or a short-lived challenge protocol, protect the server secret, and assume client-side feature gates can be patched.

## API request examples
Use HTTPS and POST JSON. `device_hash` should be a stable, app-generated identifier; avoid collecting MAC addresses or other unnecessary device identifiers.

Example verify request:
```sh
TS=$(date +%s)
DEVICE_HASH="replace_with_64_hex_device_hash"
LICENSE_KEY="AK-ABCD-1234-FFFF"
# Signature generation requires CLIENT_SECRET; never place the secret in browser JS.
SIG=$(php -r 'echo hash_hmac("sha256", $argv[1].$argv[2].$argv[3], $argv[4]);' "$TS" "$DEVICE_HASH" "$LICENSE_KEY" "YOUR_CLIENT_SECRET")
curl -i -X POST "https://example.com/api.php?action=verify" \
  -H "Content-Type: application/json" \
  -d "{\"license_key\":\"$LICENSE_KEY\",\"device_hash\":\"$DEVICE_HASH\",\"timestamp\":$TS,\"signature\":\"$SIG\"}"
```

## Security checklist before production
- Rotate the sample secret and database password.
- Remove `admin/setup_admin.php`.
- Enable HTTPS and verify the redirect and cookie behavior.
- Configure server-side rate limits at the host/WAF layer; the starter login counter stores attempts in MySQL and should be load-tested.
- Add CSRF tokens to every admin POST form.
- Back up database securely and restrict access to backups.
- Audit admin CRUD permissions, pagination, session expiry, device resets, and secret rotation.
- Never trust the client to enforce feature access by itself.
