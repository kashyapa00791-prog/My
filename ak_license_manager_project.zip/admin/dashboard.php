<?php
require_once __DIR__.'/includes/auth.php';
function scalar_count(string $sql): int { return (int)db()->query($sql)->fetch_row()[0]; }
$total=scalar_count('SELECT COUNT(*) FROM users');
$active=scalar_count('SELECT COUNT(*) FROM users WHERE is_banned=0 AND expires_at>UTC_TIMESTAMP()');
$expired=scalar_count('SELECT COUNT(*) FROM users WHERE expires_at<=UTC_TIMESTAMP()');
$banned=scalar_count('SELECT COUNT(*) FROM users WHERE is_banned=1');
$online=scalar_count('SELECT COUNT(DISTINCT user_id) FROM sessions WHERE expires_at>UTC_TIMESTAMP() AND created_at>=UTC_TIMESTAMP()-INTERVAL 5 MINUTE');
$today=scalar_count('SELECT COUNT(*) FROM users WHERE created_at>=UTC_DATE()');
$recent=db()->query('SELECT l.*,u.username FROM logs l LEFT JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 10');
$page_title='Dashboard'; require __DIR__.'/includes/header.php';
?><div class="row g-3"><?php foreach(['Total users'=>$total,'Active users'=>$active,'Expired'=>$expired,'Banned'=>$banned,'Online (recent sessions)'=>$online,'New today'=>$today] as $label=>$n): ?><div class="col-6 col-lg-4"><div class="card p-3"><div class="muted"><?= h($label) ?></div><h2><?= (int)$n ?></h2></div></div><?php endforeach; ?></div>
<div class="card p-3 mt-4"><h5>Recent activity</h5><div class="table-responsive"><table class="table table-sm"><thead><tr><th>Time (UTC)</th><th>User</th><th>Action</th><th>IP</th><th>Details</th></tr></thead><tbody><?php while($r=$recent->fetch_assoc()): ?><tr><td><?= h($r['created_at']) ?></td><td><?= h($r['username']??'—') ?></td><td><?= h($r['action']) ?></td><td><?= h($r['ip_address']??'') ?></td><td><?= h($r['extra']??'') ?></td></tr><?php endwhile; ?></tbody></table></div></div>
<div class="card p-3 mt-4"><h5>Signups over last 7 days</h5><div class="table-responsive"><table class="table"><thead><tr><th>Date</th><th>Signups</th></tr></thead><tbody><?php $s=db()->query('SELECT DATE(created_at) d,COUNT(*) c FROM users WHERE created_at>=UTC_DATE()-INTERVAL 6 DAY GROUP BY DATE(created_at) ORDER BY d'); while($r=$s->fetch_assoc()): ?><tr><td><?= h($r['d']) ?></td><td><?= (int)$r['c'] ?></td></tr><?php endwhile; ?></tbody></table></div></div>
<?php require __DIR__.'/includes/footer.php'; ?>
