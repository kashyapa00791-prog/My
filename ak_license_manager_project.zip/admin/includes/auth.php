<?php
require_once dirname(__DIR__, 2) . '/config.php';
if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
if (empty($_SESSION['csrf_token'])) csrf_token();
function admin_post_guard(): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        if (!verify_csrf($_POST['csrf_token'] ?? null)) {
            http_response_code(403); exit('Invalid CSRF token');
        }
    }
}
function flash_set(string $type, string $message): void { $_SESSION['flash'] = ['type'=>$type,'message'=>$message]; }
function flash_get(): ?array { $v=$_SESSION['flash']??null; unset($_SESSION['flash']); return $v; }
