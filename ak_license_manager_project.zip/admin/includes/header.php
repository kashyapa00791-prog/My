<?php
require_once __DIR__ . '/auth.php';
$page_title = $page_title ?? 'Dashboard';
$flash = flash_get();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($page_title) ?> - AK License Manager</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#111827;color:#e5e7eb}.navbar,.card,.table{--bs-card-bg:#1f2937;color:#e5e7eb}
.card{background:#1f2937;border:1px solid #374151}.table{--bs-table-bg:#1f2937;--bs-table-color:#e5e7eb;--bs-table-border-color:#374151}
.form-control,.form-select{background:#111827;color:#e5e7eb;border-color:#4b5563}.form-control:focus,.form-select:focus{background:#111827;color:#fff}
a{color:#93c5fd}.muted{color:#9ca3af}
</style></head><body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark border-bottom border-secondary"><div class="container-fluid">
<a class="navbar-brand" href="dashboard.php">AK License Manager</a><button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="nav"><div class="navbar-nav">
<a class="nav-link" href="dashboard.php">Dashboard</a><a class="nav-link" href="users.php">Users</a><a class="nav-link" href="keys.php">Keys</a><a class="nav-link" href="logs.php">Logs</a><a class="nav-link" href="sessions.php">Sessions</a><a class="nav-link" href="settings.php">Settings</a><a class="nav-link" href="logout.php">Logout</a>
</div></div></div></nav><main class="container-fluid py-4">
<?php if ($flash): ?><div class="alert alert-<?= h($flash['type']) ?>"><?= h($flash['message']) ?></div><?php endif; ?>
