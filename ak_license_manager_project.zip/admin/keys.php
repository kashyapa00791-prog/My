<?php
require_once __DIR__.'/includes/auth.php'; admin_post_guard(); $generated=[];
if($_SERVER['REQUEST_METHOD']==='POST'){
 try {
  if(($_POST['action']??'')==='generate'){
   $n=max(1,min(500,(int)($_POST['count']??1)));$tier=(string)($_POST['tier']??'basic');$days=max(1,min(3650,(int)($_POST['days']??30)));
   $s=db()->prepare('INSERT INTO keys_pool (license_key,tier,duration_days) VALUES (?,?,?)');
   for($i=0;$i<$n;$i++){ $key=generate_license_key(); $s->bind_param('ssi',$key,$tier,$days); $s->execute(); $generated[]=$key; } $s->close(); $_SESSION['generated_keys']=$generated; flash_set('success',$n.' keys generated.');
  }
 }catch(Throwable $e){error_log('[keys] '.$e->getMessage());flash_set('danger','Key generation failed.');}
 header('Location: keys.php');exit;
}
if(isset($_GET['export']) && $_GET['export']==='csv'){
 header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="license-keys.csv"');
 $out=fopen('php://output','w');fputcsv($out,['license_key','tier','duration_days','is_used','created_at']);
 $r=db()->query('SELECT license_key,tier,duration_days,is_used,created_at FROM keys_pool ORDER BY id DESC');
 while($row=$r->fetch_assoc())fputcsv($out,$row);fclose($out);exit;
}
$generated=$_SESSION['generated_keys']??[];unset($_SESSION['generated_keys']);$page_title='Keys';require __DIR__.'/includes/header.php';
?><h3>License keys</h3><div class="card p-3 my-3"><form method="post" class="row g-2"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="generate"><div class="col-md-3"><label class="form-label">Count (1–500)</label><input class="form-control" type="number" name="count" min="1" max="500" value="10" required></div><div class="col-md-3"><label class="form-label">Tier</label><select class="form-select" name="tier"><?php $t=db()->query('SELECT tier_name FROM tiers ORDER BY display_order');while($x=$t->fetch_assoc()): ?><option><?= h($x['tier_name']) ?></option><?php endwhile; ?></select></div><div class="col-md-3"><label class="form-label">Duration (days)</label><input class="form-control" type="number" name="days" min="1" max="3650" value="30"></div><div class="col-md-3 d-flex align-items-end"><button class="btn btn-primary">Generate</button></div></form></div>
<?php if($generated): ?><div class="card p-3 mb-3"><h5>New keys (shown once)</h5><textarea class="form-control" rows="5" readonly><?= h(implode("\n",$generated)) ?></textarea></div><?php endif; ?>
<p><a class="btn btn-outline-light" href="?export=csv">Export CSV</a></p><div class="card p-3"><div class="table-responsive"><table class="table"><thead><tr><th>Key</th><th>Tier</th><th>Days</th><th>Used</th><th>Created</th></tr></thead><tbody><?php $r=db()->query('SELECT * FROM keys_pool ORDER BY id DESC LIMIT 100');while($k=$r->fetch_assoc()): ?><tr><td><code><?= h($k['license_key']) ?></code></td><td><?= h($k['tier']) ?></td><td><?= (int)$k['duration_days'] ?></td><td><?= (int)$k['is_used']?'Yes':'No' ?></td><td><?= h($k['created_at']) ?></td></tr><?php endwhile; ?></tbody></table></div></div><?php require __DIR__.'/includes/footer.php'; ?>
