<?php
require_once dirname(__DIR__).'/config.php';
if (!empty($_SESSION['admin_id'])) { header('Location: dashboard.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $username=trim((string)($_POST['username']??'')); $password=(string)($_POST['password']??'');
    $ip=client_ip();
    try {
        $s=db()->prepare('SELECT COUNT(*) c FROM admin_login_attempts WHERE ip_address=? AND attempted_at >= (UTC_TIMESTAMP() - INTERVAL 15 MINUTE)');
        $s->bind_param('s',$ip); $s->execute(); $n=(int)$s->get_result()->fetch_assoc()['c']; $s->close();
        if ($n>=10) { $error='Too many attempts. Try again later.'; }
        else {
            $s=db()->prepare('SELECT id,password_hash FROM admin_users WHERE username=? LIMIT 1'); $s->bind_param('s',$username); $s->execute(); $u=$s->get_result()->fetch_assoc(); $s->close();
            $ok=$u && password_verify($password,$u['password_hash']);
            $s=db()->prepare('INSERT INTO admin_login_attempts (username,ip_address,was_successful) VALUES (?,?,?)'); $s->bind_param('ssi',$username,$ip,$okInt); $okInt=$ok?1:0; $s->execute(); $s->close();
            if ($ok) { session_regenerate_id(true); $_SESSION['admin_id']=(int)$u['id']; $_SESSION['admin_username']=$username; csrf_token(); header('Location: dashboard.php'); exit; }
            usleep(500000); $error='Invalid credentials.';
        }
    } catch(Throwable $e) { error_log('[admin login] '.$e->getMessage()); $error='Login unavailable. Check database setup.'; }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><style>body{background:#111827;color:#eee}.box{max-width:420px;margin:10vh auto;background:#1f2937;padding:2rem;border-radius:12px}.form-control{background:#111827;color:#eee}</style></head><body><div class="box"><h3>Admin Login</h3><?php if($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?><form method="post"><label class="form-label">Username</label><input class="form-control mb-3" name="username" required maxlength="64"><label class="form-label">Password</label><input class="form-control mb-3" type="password" name="password" required><button class="btn btn-primary w-100">Sign in</button></form></div></body></html>