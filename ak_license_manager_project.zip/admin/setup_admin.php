<?php
/*
 * Run once after importing db.sql, then DELETE this file.
 * Protect it with hosting access controls while setting up.
 */
require_once dirname(__DIR__).'/config.php';
$done=false;$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $username=trim((string)($_POST['username']??'admin'));$password=(string)($_POST['password']??'');
 if(!preg_match('/^[A-Za-z0-9_.-]{3,64}$/',$username)||strlen($password)<12)$error='Use a valid username and a password of at least 12 characters.';
 else try{$hash=password_hash($password,PASSWORD_BCRYPT,['cost'=>BCRYPT_COST]);$s=db()->prepare('INSERT INTO admin_users(username,password_hash) VALUES(?,?)');$s->bind_param('ss',$username,$hash);$s->execute();$s->close();$done=true;}catch(Throwable $e){error_log('[setup_admin] '.$e->getMessage());$error='Could not create admin. The username may already exist.';}
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin setup</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head><body class="bg-dark text-light"><main class="container py-5" style="max-width:560px"><h2>Create first admin</h2><?php if($done):?><div class="alert alert-success">Admin created. Delete admin/setup_admin.php immediately.</div><?php else:?><?php if($error):?><div class="alert alert-danger"><?=h($error)?></div><?php endif;?><form method="post"><label class="form-label">Username</label><input class="form-control mb-3" name="username" value="admin" required><label class="form-label">Password (12+ characters)</label><input class="form-control mb-3" type="password" name="password" minlength="12" required><button class="btn btn-primary">Create admin</button></form><?php endif;?></main></body></html>
