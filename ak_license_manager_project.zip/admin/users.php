<?php
require_once __DIR__.'/includes/auth.php'; admin_post_guard();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        $action=$_POST['action']??'';
        if ($action==='add') {
            $username=trim((string)($_POST['username']??'')); $password=(string)($_POST['password']??'');
            $email=trim((string)($_POST['email']??'')); $tier=(string)($_POST['tier']??'basic');
            $days=max(1,min(3650,(int)($_POST['duration_days']??30))); $max=max(1,min(100,(int)($_POST['max_devices']??1)));
            if (!preg_match('/^[A-Za-z0-9_.-]{3,64}$/',$username) || strlen($password)<10 || ($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))) throw new RuntimeException('Invalid username, password, or email.');
            $key=generate_license_key(); $hash=password_hash($password,PASSWORD_BCRYPT,['cost'=>BCRYPT_COST]); $expires=gmdate('Y-m-d H:i:s',time()+$days*86400);
            $s=db()->prepare('INSERT INTO users (username,password_hash,email,license_key,tier,expires_at,max_devices) VALUES (?,?,?,?,?,?,?)');
            $s->bind_param('ssssssi',$username,$hash,$email,$key,$tier,$expires,$max); $s->execute(); $s->close();
            flash_set('success','User created. License key: '.$key);
        } elseif ($action==='ban' || $action==='unban') {
            $id=(int)($_POST['id']??0); $b=$action==='ban'?1:0; $reason=trim((string)($_POST['reason']??'Admin action'));
            $s=db()->prepare('UPDATE users SET is_banned=?,ban_reason=? WHERE id=?'); $s->bind_param('isi',$b,$reason,$id); $s->execute(); $s->close();
            if ($b) { $s=db()->prepare('DELETE FROM sessions WHERE user_id=?'); $s->bind_param('i',$id); $s->execute(); $s->close(); }
            log_event($id,$action,null,'Admin action'); flash_set('success','User updated.');
        } elseif ($action==='delete') {
            $id=(int)($_POST['id']??0); $s=db()->prepare('DELETE FROM users WHERE id=?'); $s->bind_param('i',$id); $s->execute(); $s->close(); flash_set('success','User deleted.');
        } elseif ($action==='extend') {
            $id=(int)($_POST['id']??0); $days=max(1,min(3650,(int)($_POST['days']??30)));
            $s=db()->prepare('UPDATE users SET expires_at=DATE_ADD(GREATEST(expires_at,UTC_TIMESTAMP()), INTERVAL ? DAY) WHERE id=?'); $s->bind_param('ii',$days,$id); $s->execute(); $s->close(); flash_set('success','Expiry extended.');
        } elseif ($action==='reset_devices') {
            $id=(int)($_POST['id']??0); $s=db()->prepare('DELETE FROM devices WHERE user_id=?'); $s->bind_param('i',$id); $s->execute(); $s->close(); $s=db()->prepare('DELETE FROM sessions WHERE user_id=?'); $s->bind_param('i',$id); $s->execute(); $s->close(); flash_set('success','Devices and sessions reset.');
        } elseif ($action==='delete_all_selected') {
            foreach(($_POST['ids']??[]) as $raw){$id=(int)$raw;if($id>0){$s=db()->prepare('DELETE FROM users WHERE id=?');$s->bind_param('i',$id);$s->execute();$s->close();}}
            flash_set('success','Selected users deleted.');
        }
    } catch(Throwable $e) { error_log('[users] '.$e->getMessage()); flash_set('danger','Action failed. Check input and server logs.'); }
    header('Location: users.php'); exit;
}
$q=trim((string)($_GET['q']??'')); $page=max(1,(int)($_GET['page']??1)); $limit=25; $offset=($page-1)*$limit;
$where=''; $params=[]; $types='';
if($q!==''){ $where='WHERE username LIKE ? OR email LIKE ? OR license_key LIKE ?'; $like='%'.$q.'%'; $params=[$like,$like,$like]; $types='sss'; }
$sql='SELECT id,username,email,license_key,tier,expires_at,is_banned,max_devices,created_at FROM users '.$where.' ORDER BY created_at DESC LIMIT ? OFFSET ?';
$s=db()->prepare($sql); if($types!==''){ $types.='ii';$params[]=$limit;$params[]=$offset;$s->bind_param($types,...$params);}else{$s->bind_param('ii',$limit,$offset);} $s->execute(); $rows=$s->get_result();
$page_title='Users'; require __DIR__.'/includes/header.php';
?><div class="d-flex justify-content-between flex-wrap gap-2 mb-3"><h3>Users</h3><form class="d-flex"><input class="form-control me-2" name="q" value="<?= h($q) ?>" placeholder="Search user, email, key"><button class="btn btn-outline-light">Search</button></form></div>
<div class="card p-3 mb-4"><h5>Add user</h5><form method="post" class="row g-2"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="add">
<div class="col-md-2"><input class="form-control" name="username" placeholder="Username" required minlength="3" maxlength="64"></div><div class="col-md-2"><input class="form-control" type="password" name="password" placeholder="Password (10+ chars)" required minlength="10"></div><div class="col-md-2"><input class="form-control" type="email" name="email" placeholder="Email"></div>
<div class="col-md-2"><select class="form-select" name="tier"><?php $tiers=db()->query('SELECT tier_name FROM tiers ORDER BY display_order'); while($t=$tiers->fetch_assoc()): ?><option><?= h($t['tier_name']) ?></option><?php endwhile; ?></select></div><div class="col-md-2"><input class="form-control" type="number" name="duration_days" value="30" min="1" max="3650" required></div><div class="col-md-1"><input class="form-control" type="number" name="max_devices" value="1" min="1" max="100" required></div><div class="col-md-1"><button class="btn btn-primary w-100">Add</button></div></form></div>
<div class="card p-3"><div class="table-responsive"><table class="table table-sm align-middle"><thead><tr><th>ID</th><th>Username</th><th>License</th><th>Tier</th><th>Expiry</th><th>Status</th><th>Actions</th></tr></thead><tbody><?php while($u=$rows->fetch_assoc()): ?><tr><td><?= (int)$u['id'] ?></td><td><?= h($u['username']) ?><div class="muted"><?= h($u['email']??'') ?></div></td><td><code><?= h($u['license_key']) ?></code></td><td><?= h($u['tier']) ?></td><td><?= h($u['expires_at']) ?></td><td><?= (int)$u['is_banned']?'Banned':(strtotime($u['expires_at'].' UTC')<=time()?'Expired':'Active') ?></td><td><div class="d-flex flex-wrap gap-1">
<?php foreach(['ban'=>'Ban','unban'=>'Unban','extend'=>'+30 days','reset_devices'=>'Reset devices','delete'=>'Delete'] as $a=>$label): ?><form method="post" onsubmit="return <?= $a==='delete'?'confirm(\'Delete this user permanently?\')':'true' ?>;"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="<?= h($a) ?>"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><?php if($a==='extend'): ?><input type="hidden" name="days" value="30"><?php endif; ?><button class="btn btn-sm <?= $a==='delete'?'btn-danger':'btn-outline-light' ?>"><?= h($label) ?></button></form><?php endforeach; ?>
</div></td></tr><?php endwhile; ?></tbody></table></div><div class="d-flex gap-2"><a class="btn btn-outline-light" href="?q=<?= urlencode($q) ?>&page=<?= max(1,$page-1) ?>">Previous</a><a class="btn btn-outline-light" href="?q=<?= urlencode($q) ?>&page=<?= $page+1 ?>">Next</a></div></div>
<?php require __DIR__.'/includes/footer.php'; ?>
