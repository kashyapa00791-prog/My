<?php
declare(strict_types=1);
require __DIR__ . '/config.php';

function setting(string $key, string $default = ''): string {
    $stmt = db()->prepare('SELECT setting_value FROM settings WHERE setting_key=?');
    $stmt->bind_param('s', $key); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
    return $row ? (string)$row['setting_value'] : $default;
}
function api_fail(string $code, string $message, int $status = 400): void {
    json_response(['status'=>'error','code'=>$code,'message'=>$message], $status);
}
function require_string(array $d, string $key, int $max = 255): string {
    $v = $d[$key] ?? null;
    if (!is_string($v) || trim($v)==='' || strlen($v)>$max) api_fail('BAD_REQUEST', 'Missing or invalid field: '.$key, 400);
    return trim($v);
}
function verify_request_signature(array $d, string $messageFields): void {
    $ts = filter_var($d['timestamp'] ?? null, FILTER_VALIDATE_INT);
    $device = require_string($d, 'device_hash', 128);
    $sig = strtolower(require_string($d, 'signature', 128));
    if (!$ts || abs(time() - $ts) > REQUEST_TOLERANCE) api_fail('STALE_TIMESTAMP', 'Timestamp outside allowed window', 401);
    if (!preg_match('/^[a-f0-9]{64}$/', $sig)) api_fail('BAD_SIGNATURE', 'Invalid signature', 401);
    $message = (string)$ts . $device;
    if ($messageFields !== '') $message .= require_string($d, $messageFields, 128);
    $expected = hash_hmac('sha256', $message, CLIENT_SECRET);
    if (CLIENT_SECRET === 'REPLACE_WITH_RANDOM_64_HEX_CHAR_SECRET' || !hash_equals($expected, $sig)) {
        api_fail('BAD_SIGNATURE', 'Signature verification failed', 401);
    }
}
function maintenance_check(): void {
    if (setting('maintenance_mode', '0') === '1') json_response(['status'=>'error','code'=>'MAINTENANCE','message'=>'Service temporarily unavailable'], 503);
}
function rate_limit_login(string $username): void {
    $ip = client_ip();
    $stmt = db()->prepare('SELECT COUNT(*) c FROM api_login_attempts WHERE ip_address=? AND attempted_at >= (UTC_TIMESTAMP() - INTERVAL 1 MINUTE)');
    $stmt->bind_param('s', $ip); $stmt->execute();
    $count = (int)$stmt->get_result()->fetch_assoc()['c']; $stmt->close();
    if ($count >= 5) api_fail('RATE_LIMITED', 'Too many login attempts', 429);
}
function record_login_attempt(string $username, bool $ok): void {
    $stmt = db()->prepare('INSERT INTO api_login_attempts (ip_address, username, was_successful) VALUES (?, ?, ?)');
    $ip=client_ip(); $success=$ok?1:0;
    $stmt->bind_param('ssi', $ip, $username, $success); $stmt->execute(); $stmt->close();
}
function load_user_by_key(string $key): ?array {
    $key = strtoupper(trim($key));
    $stmt = db()->prepare('SELECT * FROM users WHERE license_key=? LIMIT 1');
    $stmt->bind_param('s', $key); $stmt->execute(); $row=$stmt->get_result()->fetch_assoc(); $stmt->close();
    return $row ?: null;
}
function check_user_status(array $u): void {
    if ((int)$u['is_banned'] === 1) json_response(['status'=>'banned','reason'=>$u['ban_reason'] ?: 'Account disabled'], 403);
    if (strtotime($u['expires_at'].' UTC') <= time()) api_fail('LICENSE_EXPIRED', 'License has expired', 410);
}
function bind_device(array $u, string $device, ?string $name): void {
    $conn=db(); $uid=(int)$u['id'];
    $stmt=$conn->prepare('SELECT id FROM devices WHERE user_id=? AND device_hash=? LIMIT 1');
    $stmt->bind_param('is',$uid,$device); $stmt->execute(); $existing=$stmt->get_result()->fetch_assoc(); $stmt->close();
    if ($existing) {
        $stmt=$conn->prepare('UPDATE devices SET is_active=1,last_seen=UTC_TIMESTAMP(),device_name=COALESCE(?,device_name) WHERE id=?');
        $did=(int)$existing['id']; $stmt->bind_param('si',$name,$did); $stmt->execute(); $stmt->close(); return;
    }
    $stmt=$conn->prepare('SELECT COUNT(*) c FROM devices WHERE user_id=? AND is_active=1');
    $stmt->bind_param('i',$uid); $stmt->execute(); $count=(int)$stmt->get_result()->fetch_assoc()['c']; $stmt->close();
    if ($count >= (int)$u['max_devices']) api_fail('DEVICE_LIMIT','Maximum registered devices reached',403);
    $stmt=$conn->prepare('INSERT INTO devices (user_id,device_hash,device_name) VALUES (?,?,?)');
    $stmt->bind_param('iss',$uid,$device,$name); $stmt->execute(); $stmt->close();
}
function get_features(string $tier): array {
    $stmt=db()->prepare('SELECT features_json FROM tiers WHERE tier_name=?');
    $stmt->bind_param('s',$tier); $stmt->execute(); $row=$stmt->get_result()->fetch_assoc(); $stmt->close();
    $features=$row ? json_decode($row['features_json'],true) : [];
    return is_array($features) ? $features : [];
}

try {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') api_fail('METHOD_NOT_ALLOWED','POST required',405);
    maintenance_check();
    $action = (string)($_GET['action'] ?? '');
    $d = request_data();
    if ($action === 'login') {
        $username=require_string($d,'username',64);
        $password=require_string($d,'password',1024);
        verify_request_signature($d, '');
        rate_limit_login($username);
        $stmt=db()->prepare('SELECT * FROM users WHERE username=? LIMIT 1');
        $stmt->bind_param('s',$username); $stmt->execute(); $u=$stmt->get_result()->fetch_assoc(); $stmt->close();
        if (!$u || !password_verify($password,$u['password_hash'])) {
            record_login_attempt($username,false); usleep(500000);
            api_fail('INVALID_CREDENTIALS','Invalid credentials',401);
        }
        record_login_attempt($username,true); check_user_status($u);
        $device=require_string($d,'device_hash',128);
        bind_device($u,$device,isset($d['device_name'])?substr((string)$d['device_name'],0,128):null);
        $token=generate_session_token(); $uid=(int)$u['id']; $expiry=gmdate('Y-m-d H:i:s',time()+SESSION_TTL); $ip=client_ip();
        $stmt=db()->prepare('INSERT INTO sessions (user_id,token,device_hash,expires_at,ip_address) VALUES (?,?,?,?,?)');
        $stmt->bind_param('issss',$uid,$token,$device,$expiry,$ip); $stmt->execute(); $stmt->close();
        $stmt=db()->prepare('UPDATE users SET last_login=UTC_TIMESTAMP() WHERE id=?'); $stmt->bind_param('i',$uid); $stmt->execute(); $stmt->close();
        log_event($uid,'login',$device,'API login');
        json_response(['status'=>'ok','data'=>['token'=>$token,'expires_at'=>$expiry,'user'=>['username'=>$u['username'],'tier'=>$u['tier'],'features'=>get_features($u['tier']),'expires_at'=>$u['expires_at']]]]);
    }
    if ($action === 'verify') {
        verify_request_signature($d,'license_key');
        $key=strtoupper(require_string($d,'license_key',64)); $device=require_string($d,'device_hash',128);
        $u=load_user_by_key($key); if (!$u) api_fail('INVALID_LICENSE','License not found',401);
        check_user_status($u); bind_device($u,$device,isset($d['device_name'])?substr((string)$d['device_name'],0,128):null);
        log_event((int)$u['id'],'license_verify',$device,'License verified');
        json_response(['status'=>'ok','data'=>['valid'=>true,'expires_in_seconds'=>max(0,strtotime($u['expires_at'].' UTC')-time()),'tier'=>$u['tier'],'features'=>get_features($u['tier'])]]);
    }
    if ($action === 'heartbeat' || $action === 'logout' || $action === 'user_info') {
        $device = isset($d['device_hash']) ? require_string($d,'device_hash',128) : '';
        if ($action !== 'user_info') verify_request_signature($d,'token');
        else {
            $ts=filter_var($d['timestamp']??null,FILTER_VALIDATE_INT);
            $sig=strtolower(require_string($d,'signature',128)); $token=require_string($d,'token',128);
            if (!$ts || abs(time()-$ts)>REQUEST_TOLERANCE || !preg_match('/^[a-f0-9]{64}$/',$sig) ||
                !hash_equals(hash_hmac('sha256',(string)$ts.$token,CLIENT_SECRET),$sig)) api_fail('BAD_SIGNATURE','Signature verification failed',401);
        }
        $token=require_string($d,'token',128);
        $stmt=db()->prepare('SELECT s.*,s.expires_at AS session_expires_at,u.username,u.tier,u.expires_at AS license_expires_at,u.is_banned,u.ban_reason,u.id AS uid FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? LIMIT 1');
        $stmt->bind_param('s',$token); $stmt->execute(); $row=$stmt->get_result()->fetch_assoc(); $stmt->close();
        if (!$row) api_fail('INVALID_SESSION','Session not found',401);
        if ($action === 'logout') {
            $stmt=db()->prepare('DELETE FROM sessions WHERE token=?'); $stmt->bind_param('s',$token); $stmt->execute(); $stmt->close();
            if ($device !== '') { $stmt=db()->prepare('UPDATE devices SET is_active=0 WHERE user_id=? AND device_hash=?'); $uid=(int)$row['uid']; $stmt->bind_param('is',$uid,$device); $stmt->execute(); $stmt->close(); }
            log_event((int)$row['uid'],'logout',$device ?: null,'Client logout');
            json_response(['status'=>'ok','data'=>['logged_out'=>true]]);
        }
        if ($device !== '' && !hash_equals((string)$row['device_hash'],$device)) api_fail('DEVICE_MISMATCH','Session device mismatch',403);
        if (strtotime($row['session_expires_at'].' UTC') <= time()) api_fail('SESSION_EXPIRED','Session expired',401);
        if ((int)$row['is_banned'] === 1) json_response(['status'=>'banned','reason'=>$row['ban_reason'] ?: 'Account disabled'],403);
        if (strtotime($row['license_expires_at'].' UTC') <= time()) api_fail('LICENSE_EXPIRED','License expired',410);
        if ($action === 'heartbeat') {
            $stmt=db()->prepare('UPDATE devices SET last_seen=UTC_TIMESTAMP() WHERE user_id=? AND device_hash=? AND is_active=1');
            $uid=(int)$row['uid']; $stmt->bind_param('is',$uid,$device); $stmt->execute(); $stmt->close();
            json_response(['status'=>'ok','data'=>['remaining_seconds'=>max(0,strtotime($row['license_expires_at'].' UTC')-time())]]);
        }
        json_response(['status'=>'ok','data'=>['user'=>['username'=>$row['username'],'tier'=>$row['tier'],'expires_at'=>$row['license_expires_at'],'features'=>get_features($row['tier'])]]]);
    }
    api_fail('UNKNOWN_ACTION','Unknown action',404);
} catch (Throwable $e) {
    error_log('[api] '.gmdate('c').' '.$e->getMessage());
    json_response(['status'=>'error','code'=>'SERVER_ERROR','message'=>'An internal error occurred'],500);
}
