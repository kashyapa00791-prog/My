<?php
declare(strict_types=1);

/*
 * Copy this file outside the public web root if your host supports it.
 * Otherwise protect it with .htaccess and restrictive file permissions.
 */
define('APP_NAME', 'AK License Manager');
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_database');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'replace_with_database_password');
define('DB_CHARSET', 'utf8mb4');
define('CLIENT_SECRET', 'REPLACE_WITH_RANDOM_64_HEX_CHAR_SECRET');
define('SESSION_TTL', 86400);
define('REQUEST_TOLERANCE', 300);
define('BCRYPT_COST', 12);
define('COOKIE_SECURE', true); // Set false only for local HTTP development.
date_default_timezone_set('UTC');

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'domain' => '',
        'secure' => COOKIE_SECURE, 'httponly' => true, 'samesite' => 'Strict'
    ]);
    session_start();
}

function db(): mysqli {
    static $conn = null;
    if ($conn instanceof mysqli) return $conn;
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $conn->set_charset(DB_CHARSET);
        return $conn;
    } catch (Throwable $e) {
        error_log('[db] ' . gmdate('c') . ' ' . $e->getMessage());
        throw new RuntimeException('Database unavailable');
    }
}
function h($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function json_response(array $body, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($body, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function request_data(): array {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        json_response(['status'=>'error','code'=>'METHOD_NOT_ALLOWED','message'=>'POST required'], 405);
    }
    $type = strtolower(trim(explode(';', $_SERVER['CONTENT_TYPE'] ?? '')[0]));
    if ($type === 'application/json') {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw ?: '', true);
        if (!is_array($data) || json_last_error() !== JSON_ERROR_NONE) {
            json_response(['status'=>'error','code'=>'INVALID_JSON','message'=>'Invalid JSON'], 400);
        }
        return $data;
    }
    return $_POST;
}
function client_ip(): string {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
}
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function verify_csrf($token): bool {
    return is_string($token) && isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
function generate_session_token(): string { return bin2hex(random_bytes(32)); }
function generate_license_key(): string {
    return 'AK-' . strtoupper(bin2hex(random_bytes(2))) . '-' .
        strtoupper(bin2hex(random_bytes(2))) . '-' . strtoupper(bin2hex(random_bytes(2)));
}
function log_event(?int $userId, string $action, ?string $device = null, ?string $extra = null): void {
    try {
        $stmt = db()->prepare('INSERT INTO logs (user_id, action, device_hash, ip_address, extra) VALUES (?, ?, ?, ?, ?)');
        $ip = client_ip();
        $stmt->bind_param('issss', $userId, $action, $device, $ip, $extra);
        $stmt->execute();
        $stmt->close();
    } catch (Throwable $e) {
        error_log('[log_event] ' . gmdate('c') . ' ' . $e->getMessage());
    }
}
