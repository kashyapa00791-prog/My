# Lua client integration notes

Use this only in an application environment you own or are authorized to modify.

## Request signing
The API expects:
- `login`: HMAC-SHA256(`timestamp .. device_hash`, secret)
- `verify`: HMAC-SHA256(`timestamp .. device_hash .. license_key`, secret)
- `heartbeat` and `logout`: HMAC-SHA256(`timestamp .. device_hash .. token`, secret)
- `user_info`: HMAC-SHA256(`timestamp .. token`, secret)

The client must POST JSON over HTTPS and parse the JSON response. Keep networking and HMAC operations behind the HTTP and crypto functions available in your particular Lua runtime; mobile Lua distributions differ and there is no single portable HTTP library.

## Pseudocode
```lua
local timestamp = os.time()
local message = tostring(timestamp) .. device_hash .. license_key
local signature = hmac_sha256_hex(message, secret)

local body = {
  license_key = license_key,
  device_hash = device_hash,
  timestamp = timestamp,
  signature = signature
}

local response = http_post_json(
  "https://example.com/api.php?action=verify",
  body
)

if response.status == "ok" and response.data.valid then
  -- Enable only features belonging to your authorized application.
else
  -- Keep protected application functionality locked.
end
```

`hmac_sha256_hex` and `http_post_json` above are adapter names, not built-in Lua functions. Implement them using libraries actually present in your runtime. Do not ship `CLIENT_SECRET` inside a publicly distributed Lua file: a user can extract it and forge requests. For stronger security, use a server challenge with asymmetric signatures or another protocol where the client does not contain the server's signing secret.
