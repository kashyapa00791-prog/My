# API curl smoke tests

Set values first. These examples show request shapes; signatures must be computed with the same secret and exact message order as `README.md`.

```sh
BASE="https://example.com/api.php"
TS=$(date +%s)
DEVICE_HASH="replace_with_device_hash"
LICENSE_KEY="AK-ABCD-1234-FFFF"
CLIENT_SECRET="replace_with_your_secret"
```

## Verify
```sh
SIG=$(php -r 'echo hash_hmac("sha256",$argv[1].$argv[2].$argv[3],$argv[4]);' "$TS" "$DEVICE_HASH" "$LICENSE_KEY" "$CLIENT_SECRET")
curl -i -X POST "$BASE?action=verify" -H 'Content-Type: application/json' \
  -d "{\"license_key\":\"$LICENSE_KEY\",\"device_hash\":\"$DEVICE_HASH\",\"timestamp\":$TS,\"signature\":\"$SIG\"}"
```

## Login
```sh
SIG=$(php -r 'echo hash_hmac("sha256",$argv[1].$argv[2],$argv[3]);' "$TS" "$DEVICE_HASH" "$CLIENT_SECRET")
curl -i -X POST "$BASE?action=login" -H 'Content-Type: application/json' \
  -d "{\"username\":\"demo\",\"password\":\"replace_password\",\"device_hash\":\"$DEVICE_HASH\",\"timestamp\":$TS,\"signature\":\"$SIG\"}"
```

## Heartbeat / logout
For these calls, set `TOKEN` to the token returned by login and recompute timestamp/signature before each request:
```sh
TOKEN="paste_login_token"
TS=$(date +%s)
SIG=$(php -r 'echo hash_hmac("sha256",$argv[1].$argv[2].$argv[3],$argv[4]);' "$TS" "$DEVICE_HASH" "$TOKEN" "$CLIENT_SECRET")
curl -i -X POST "$BASE?action=heartbeat" -H 'Content-Type: application/json' \
  -d "{\"token\":\"$TOKEN\",\"device_hash\":\"$DEVICE_HASH\",\"timestamp\":$TS,\"signature\":\"$SIG\"}"
curl -i -X POST "$BASE?action=logout" -H 'Content-Type: application/json' \
  -d "{\"token\":\"$TOKEN\",\"device_hash\":\"$DEVICE_HASH\",\"timestamp\":$TS,\"signature\":\"$SIG\"}"
```

## User info
```sh
TOKEN="paste_login_token"
TS=$(date +%s)
SIG=$(php -r 'echo hash_hmac("sha256",$argv[1].$argv[2],$argv[3]);' "$TS" "$TOKEN" "$CLIENT_SECRET")
curl -i -X POST "$BASE?action=user_info" -H 'Content-Type: application/json' \
  -d "{\"token\":\"$TOKEN\",\"timestamp\":$TS,\"signature\":\"$SIG\"}"
```

A 401 indicates signature, credentials, or session failure; 403 indicates ban/device restrictions; 410 indicates expired license; 429 indicates throttling. Check server logs for database/setup errors.
